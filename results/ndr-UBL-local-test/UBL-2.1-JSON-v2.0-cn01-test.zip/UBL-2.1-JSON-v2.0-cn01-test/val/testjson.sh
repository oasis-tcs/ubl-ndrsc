sh validatejson.sh ../json-schema-legacy/maindoc/UBL-Order-2.1.json order-test-bad1.json
sh validatejson.sh ../json-schema-legacy/maindoc/UBL-Order-2.1.json order-test-bad2.json
sh validatejson.sh ../json-schema-legacy/maindoc/UBL-Order-2.1.json order-test-bad3.json
sh validatejson.sh ../json-schema-legacy/maindoc/UBL-Order-2.1.json order-test-bad4.json
sh validatejson.sh ../json-schema-legacy/maindoc/UBL-Order-2.1.json order-test-good.json
